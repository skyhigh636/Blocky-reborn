using Godot;
using System;
using System.Timers;

public partial class Player : Area2D
{
    static System.Timers.Timer _timer = new System.Timers.Timer(1000);
    
    
    [Signal]
    public delegate void HitEventHandler();

    [Export] public float Speed = 400f;

    private Vector2 _screenSize;

    public override void _Ready()
    {
        _screenSize = GetViewportRect().Size;
    }

    public void Start(Vector2 pos)
    {
        Position = pos;
        Show();
        GetNode<CollisionShape2D>("CollisionShape2D").Disabled = false;
    }

    public override void _Process(double delta)
    {
        Vector2 velocity = Vector2.Zero;

        if (Input.IsActionPressed("move_right"))
            velocity.X += 1;
        if (Input.IsActionPressed("move_left"))
            velocity.X -= 1;
        if (Input.IsActionPressed("move_down"))
            velocity.Y += 1;
        if (Input.IsActionPressed("move_up"))
            velocity.Y -= 1;

        if (velocity.Length() > 0)
        {
            velocity = velocity.Normalized() * Speed;
            GetNode<AnimatedSprite2D>("AnimatedSprite2D").Play();
        }


        Position += velocity * (float)delta;
        Position = Position.Clamp(Vector2.Zero, _screenSize);
        if (Input.IsActionJustPressed("Shoot"))
        {
            GetNode<AnimatedSprite2D>("AnimatedSprite2D/Shots").Play();
        }
        else
        {
            GetNode<AnimatedSprite2D>("AnimatedSprite2D").Play();
        }
    }

    private void OnBodyEntered(Node2D body)
    {
        Hide();
        EmitSignal(SignalName.Hit);
        GetNode<CollisionShape2D>("CollisionShape2D").SetDeferred("disabled", true);
    }
}