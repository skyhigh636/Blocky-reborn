using Godot;
using System;

public partial class Rocket : RigidBody2D
{
    public float MaxDistance = 600;
    public float Impulse = 1000;
    public float Lifetime = 1;
    private Vector2 originPosition;
    private Timer timer;
    
    public void Shoot()
    {
        originPosition = Position;
        ApplyCentralImpulse(Transform.X.Normalized() * Impulse);

        timer = new Timer();
        timer.WaitTime = Lifetime;
        timer.OneShot = true;
        timer.Timeout += OnTimerTimeout; // Subscribe to the Timeout event
        AddChild(timer); // Add timer to the scene tree
        timer.Start();
    }

    public void _PhysicsProcess(float delta)
    {
        float distanceTravelled = (this.Position - originPosition).Length();
        if(distanceTravelled > MaxDistance)
            QueueFree();
    }
    public void OnTimerTimeout()
    {
        QueueFree();
    }
}


